package com.pocketdesk.app;

import android.app.Activity;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.ExifInterface;
import android.media.ToneGenerator;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.database.Cursor;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Local-only web interface, served from a fixed private origin. No network permission. */
public final class MainActivity extends Activity {
    private static final String HOST="app.pocketdesk.local";
    private static final int IMAGE=101,AUDIO=102,FILE=103,BACKUP=104,CAMERA=105,EXPORT=106;
    private WebView web;
    private SharedPreferences prefs;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private File mediaDir;
    private boolean documentBusy=false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs=getSharedPreferences("pocketdesk",MODE_PRIVATE);
        mediaDir=new File(getFilesDir(),"media");mediaDir.mkdirs();
        if(saved!=null)documentBusy=saved.getBoolean("documentBusy",false);
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(17,27,34));
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        if(Build.VERSION.SDK_INT>=26)s.setSafeBrowsingEnabled(true);
        web.addJavascriptInterface(new Bridge(),"PocketNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                Uri uri=request.getUrl();
                return !"https".equals(uri.getScheme())||!HOST.equals(uri.getHost());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                return localResponse(request);
            }
        });
        setContentView(web);
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            web.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));
                return insets;
            });
            web.requestApplyInsets();
        }
        web.loadUrl("https://"+HOST+"/index.html");
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("documentBusy",documentBusy);super.onSaveInstanceState(out);}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);js("Pocket.goHome()");}
    @Override public void onBackPressed(){js("Pocket.back()");}
    @Override protected void onPause(){js("Pocket.suspend()");super.onPause();if(web!=null)web.onPause();}
    @Override protected void onResume(){super.onResume();if(web!=null){web.onResume();js("Pocket.resume()");}}
    @Override protected void onDestroy(){worker.shutdown();if(web!=null){web.removeJavascriptInterface("PocketNative");web.destroy();}super.onDestroy();}
    private void js(String code){main.post(()->{if(web!=null&&!isFinishing()&&!isDestroyed())web.evaluateJavascript("if(window.Pocket){"+code+";}",null);});}
    private void message(String text){js("Pocket.showMessage("+JSONObject.quote(text)+")");}
    private void open(Intent i){main.post(()->{try{startActivity(i);}catch(ActivityNotFoundException|SecurityException e){message("No app on this phone can open this. Try your normal phone app.");}});}
    private JSONArray array(String key){try{return new JSONArray(prefs.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}

    private WebResourceResponse localResponse(WebResourceRequest r){
        try{
            Uri u=r.getUrl();if(!"https".equals(u.getScheme())||!HOST.equals(u.getHost()))return errorResponse();
            String path=u.getPath();if(path==null)return errorResponse();
            if(path.startsWith("/media/")){
                String name=path.substring(7);if(!name.matches("[a-f0-9-]{36}\\.(jpg|audio)"))return errorResponse();
                File f=new File(mediaDir,name);if(!f.isFile())return errorResponse();
                String mime=name.endsWith(".jpg")?"image/jpeg":"audio/mpeg";
                JSONArray items=array("media");for(int n=0;n<items.length();n++){JSONObject m=items.optJSONObject(n);if(m!=null&&name.equals(m.optString("file")))mime=m.optString("mime",mime);}
                HashMap<String,String> headers=new HashMap<>();headers.put("Accept-Ranges","bytes");headers.put("Cache-Control","private, max-age=3600");
                String range=r.getRequestHeaders().get("Range");if(range==null)range=r.getRequestHeaders().get("range");
                if(range!=null&&range.matches("bytes=\\d+-\\d*")){
                    String[] parts=range.substring(6).split("-",-1);long start=Long.parseLong(parts[0]),end=parts[1].isEmpty()?f.length()-1:Math.min(Long.parseLong(parts[1]),f.length()-1);
                    if(start<0||start>=f.length()||end<start)return errorResponse();
                    FileInputStream in=new FileInputStream(f);in.getChannel().position(start);long len=end-start+1;
                    headers.put("Content-Range","bytes "+start+"-"+end+"/"+f.length());headers.put("Content-Length",String.valueOf(len));
                    return new WebResourceResponse(mime,null,206,"Partial Content",headers,new BoundedStream(in,len));
                }
                headers.put("Content-Length",String.valueOf(f.length()));return new WebResourceResponse(mime,null,200,"OK",headers,new FileInputStream(f));
            }
            String name=path.equals("/")?"index.html":path.substring(1);
            if(!name.equals("index.html")&&!name.equals("style.css")&&!name.equals("core.js")&&!name.equals("app.js"))return errorResponse();
            String mime=name.endsWith(".html")?"text/html":name.endsWith(".css")?"text/css":"application/javascript";
            return new WebResourceResponse(mime,"UTF-8",getAssets().open(name));
        }catch(Exception e){return errorResponse();}
    }
    private WebResourceResponse errorResponse(){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",new HashMap<>(),new ByteArrayInputStream(new byte[0]));}
    private static class BoundedStream extends InputStream{
        final InputStream source;long remaining;
        BoundedStream(InputStream s,long n){source=s;remaining=n;}
        @Override public int read()throws java.io.IOException{if(remaining<=0)return -1;int v=source.read();if(v>=0)remaining--;return v;}
        @Override public int read(byte[] b,int off,int len)throws java.io.IOException{if(remaining<=0)return -1;int n=source.read(b,off,(int)Math.min(len,remaining));if(n>0)remaining-=n;return n;}
        @Override public void close()throws java.io.IOException{source.close();}
    }

    public final class Bridge {
        @JavascriptInterface public String loadState(){return prefs.getString("state","{}");}
        @JavascriptInterface public boolean saveState(String data){try{if(data==null||data.length()>1800000||new JSONObject(data).optInt("version")!=1)return false;return prefs.edit().putString("state",data).commit();}catch(Exception e){return false;}}
        @JavascriptInterface public void systemTheme(boolean light){main.post(()->{int color=light?Color.rgb(240,244,242):Color.rgb(17,27,34);getWindow().setStatusBarColor(color);getWindow().setNavigationBarColor(color);int flags=light?View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR:0;getWindow().getDecorView().setSystemUiVisibility(flags);web.setBackgroundColor(color);});}
        @JavascriptInterface public String deviceInfo(){JSONObject o=new JSONObject();try{
            o.put("model",Build.MODEL);o.put("brand",Build.MANUFACTURER);o.put("android",Build.VERSION.RELEASE);o.put("api",Build.VERSION.SDK_INT);
            Intent battery=registerReceiver(null,new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if(battery!=null){int level=battery.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=battery.getIntExtra(BatteryManager.EXTRA_SCALE,100);if(level>=0&&scale>0)o.put("battery",Math.round(level*100f/scale));o.put("charging",battery.getIntExtra(BatteryManager.EXTRA_PLUGGED,0)!=0);}
            StatFs fs=new StatFs(getFilesDir().getAbsolutePath());o.put("free",fs.getAvailableBytes());o.put("total",fs.getTotalBytes());
            ConnectivityManager c=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);NetworkInfo n=c.getActiveNetworkInfo();o.put("network",n!=null&&n.isConnected()?(n.getType()==ConnectivityManager.TYPE_WIFI?"Wi-Fi":"Mobile or other network"):"No connection");
        }catch(Exception ignored){}return o.toString();}
        @JavascriptInterface public String installedApps(){JSONArray out=new JSONArray();try{Intent q=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);ArrayList<ResolveInfo> list=new ArrayList<>(getPackageManager().queryIntentActivities(q,0));Collections.sort(list,new ResolveInfo.DisplayNameComparator(getPackageManager()));java.util.HashSet<String> seen=new java.util.HashSet<>();for(ResolveInfo r:list){String p=r.activityInfo.packageName;if(p.equals(getPackageName())||!seen.add(p))continue;JSONObject a=new JSONObject();a.put("package",p);a.put("name",r.loadLabel(getPackageManager()).toString());try{Drawable d=r.loadIcon(getPackageManager());Bitmap b=Bitmap.createBitmap(72,72,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);d.setBounds(0,0,72,72);d.draw(c);ByteArrayOutputStream bytes=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,bytes);b.recycle();a.put("icon","data:image/png;base64,"+android.util.Base64.encodeToString(bytes.toByteArray(),android.util.Base64.NO_WRAP));}catch(Exception ignored){}out.put(a);}}catch(Exception ignored){}return out.toString();}
        @JavascriptInterface public void launchPackage(String name){if(name==null||!name.matches("[A-Za-z0-9_.]+"))return;Intent i=getPackageManager().getLaunchIntentForPackage(name);if(i!=null)open(i);else message("This app could not be opened.");}
        @JavascriptInterface public void openSystem(String key){Intent i;switch(key){
            case "wifi":i=new Intent(Settings.ACTION_WIFI_SETTINGS);break;
            case "bluetooth":i=new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);break;
            case "sound":i=new Intent(Settings.ACTION_SOUND_SETTINGS);break;
            case "display":i=new Intent(Settings.ACTION_DISPLAY_SETTINGS);break;
            case "storage":i=new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);break;
            case "contacts":i=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS);break;
            case "calendar":i=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR);break;
            default:i=new Intent(Settings.ACTION_SETTINGS);
        }open(i);}
        @JavascriptInterface public void chooseHome(){main.post(()->{if(Build.VERSION.SDK_INT>=29){RoleManager rm=getSystemService(RoleManager.class);if(rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_HOME)&&!rm.isRoleHeld(RoleManager.ROLE_HOME)){try{startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME),200);return;}catch(Exception ignored){}}}open(new Intent(Settings.ACTION_HOME_SETTINGS));});}
        @JavascriptInterface public void openWebsite(String address){try{Uri u=Uri.parse(address);if(("https".equals(u.getScheme())||"http".equals(u.getScheme()))&&u.getHost()!=null&&u.getUserInfo()==null)open(new Intent(Intent.ACTION_VIEW,u).addCategory(Intent.CATEGORY_BROWSABLE));}catch(Exception ignored){message("Use a normal website address.");}}
        @JavascriptInterface public void dial(String number){open(new Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",limited(number,60),null)));}
        @JavascriptInterface public void composeMessage(String number,String text){open(new Intent(Intent.ACTION_SENDTO,Uri.fromParts("smsto",limited(number,60),null)).putExtra("sms_body",limited(text,3000)));}
        @JavascriptInterface public void setPhoneAlarm(int hour,int minute,String label){if(hour<0||hour>23||minute<0||minute>59)return;open(new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR,hour).putExtra(AlarmClock.EXTRA_MINUTES,minute).putExtra(AlarmClock.EXTRA_MESSAGE,limited(label,100)).putExtra(AlarmClock.EXTRA_SKIP_UI,false));}
        @JavascriptInterface public void setPhoneTimer(int seconds){if(seconds<1||seconds>86400)return;open(new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH,seconds).putExtra(AlarmClock.EXTRA_MESSAGE,"PocketDesk timer").putExtra(AlarmClock.EXTRA_SKIP_UI,false));}
        @JavascriptInterface public void haptic(){try{Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null&&v.hasVibrator())v.vibrate(VibrationEffect.createOneShot(8,VibrationEffect.DEFAULT_AMPLITUDE));}catch(Exception ignored){}}
        @JavascriptInterface public void timerAlert(){main.post(()->{try{final ToneGenerator t=new ToneGenerator(AudioManager.STREAM_NOTIFICATION,65);t.startTone(ToneGenerator.TONE_PROP_BEEP2,650);main.postDelayed(t::release,850);haptic();}catch(Exception ignored){}});}
        @JavascriptInterface public int getVolume(){AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE);return Math.round(a.getStreamVolume(AudioManager.STREAM_MUSIC)*100f/a.getStreamMaxVolume(AudioManager.STREAM_MUSIC));}
        @JavascriptInterface public void setVolume(int value){if(value<0||value>100)return;AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE);try{a.setStreamVolume(AudioManager.STREAM_MUSIC,Math.round(value*a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/100f),0);}catch(SecurityException e){message("Open your phone’s sound settings to change volume.");}}
        @JavascriptInterface public int getBrightness(){float value=getWindow().getAttributes().screenBrightness;if(value<0){try{return Math.round(Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS)*100f/255f);}catch(Exception e){return 70;}}return Math.round(value*100);}
        @JavascriptInterface public void setBrightness(int value){if(value<20||value>100)return;main.post(()->{WindowManager.LayoutParams p=getWindow().getAttributes();p.screenBrightness=value/100f;getWindow().setAttributes(p);});}
        @JavascriptInterface public String listMedia(){return array("media").toString();}
        @JavascriptInterface public String recentFiles(){return array("files").toString();}
        @JavascriptInterface public void pickDocument(String kind){final int request="image".equals(kind)?IMAGE:"audio".equals(kind)?AUDIO:"backup".equals(kind)?BACKUP:FILE;main.post(()->{if(documentBusy){message("Finish choosing the current file first.");return;}Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(request==IMAGE?"image/*":request==AUDIO?"audio/*":"*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{documentBusy=true;startActivityForResult(i,request);}catch(Exception e){documentBusy=false;message("The file picker could not open.");}});}
        @JavascriptInterface public void exportDocument(String name,String content,String mime){if(content==null||content.length()>2200000){message("This file is too large to export.");return;}final String safeName=limited(name,100).replaceAll("[^A-Za-z0-9 ._-]","_");main.post(()->{if(documentBusy){message("Finish choosing the current file first.");return;}try{try(FileOutputStream out=new FileOutputStream(new File(getFilesDir(),"pending-export"))){out.write(content.getBytes(StandardCharsets.UTF_8));}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json".equals(mime)?"application/json":"text/plain").putExtra(Intent.EXTRA_TITLE,safeName);documentBusy=true;startActivityForResult(i,EXPORT);}catch(Exception e){documentBusy=false;message("This file could not be exported.");}});}
        @JavascriptInterface public void takePhoto(){main.post(()->{if(documentBusy){message("Finish choosing the current file first.");return;}try{documentBusy=true;startActivityForResult(new Intent(MediaStore.ACTION_IMAGE_CAPTURE),CAMERA);}catch(Exception e){documentBusy=false;message("Your camera could not open. You can add a photo from Files.");}});}
        @JavascriptInterface public void openRecentFile(String id){JSONArray a=array("files");for(int n=0;n<a.length();n++){JSONObject x=a.optJSONObject(n);if(x!=null&&id.equals(x.optString("id"))){Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(x.optString("uri")),x.optString("mime","*/*")).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);open(i);return;}}message("Choose this file again from your phone.");}
        @JavascriptInterface public void removeMedia(String id){worker.execute(()->{try{JSONArray old=array("media"),next=new JSONArray();for(int n=0;n<old.length();n++){JSONObject x=old.getJSONObject(n);if(id.equals(x.optString("id"))){String filename=x.optString("file");if(filename.matches("[a-f0-9-]{36}\\.(jpg|audio)"))new File(mediaDir,filename).delete();}else next.put(x);}prefs.edit().putString("media",next.toString()).commit();js("Pocket.receiveMedia()");}catch(Exception e){message("This copy could not be removed.");}});}
    }
    private static String limited(String s,int n){return s==null?"":s.substring(0,Math.min(s.length(),n));}
    private JSONObject metadata(Uri u)throws Exception{JSONObject m=new JSONObject();m.put("name","Selected file");m.put("size",0);m.put("mime",getContentResolver().getType(u));try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()){m.put("name",limited(c.getString(0),200));if(!c.isNull(1))m.put("size",c.getLong(1));}}return m;}
    private byte[] readLimited(Uri u,int limit)throws Exception{try(InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new Exception();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>limit)throw new IllegalArgumentException("This file is too large.");out.write(b,0,n);}return out.toByteArray();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request<IMAGE||request>EXPORT)return;documentBusy=false;if(result!=RESULT_OK){if(request==EXPORT)new File(getFilesDir(),"pending-export").delete();return;}
        if(request==CAMERA){Bitmap image=data!=null&&data.getExtras()!=null?(Bitmap)data.getExtras().get("data"):null;if(image==null){message("Photo taken. Add it to Photos from your phone if you want a copy here.");return;}worker.execute(()->{try{addPhoto(image,"Camera photo");}catch(Exception e){message("The photo copy could not be saved.");}finally{image.recycle();}});return;}
        Uri uri=data==null?null:data.getData();if(uri==null)return;
        worker.execute(()->{try{
            if(request==EXPORT){File temp=new File(getFilesDir(),"pending-export");try(InputStream in=new FileInputStream(temp);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new Exception();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}temp.delete();js("Pocket.documentSaved()");}
            else if(request==BACKUP){String text=new String(readLimited(uri,8000000),StandardCharsets.UTF_8);js("Pocket.receiveBackup("+JSONObject.quote(text)+")");}
            else if(request==IMAGE){JSONObject m=metadata(uri);BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,options);}if(options.outWidth<=0||options.outHeight<=0)throw new IllegalArgumentException("This image could not be read. Try JPG or PNG.");options.inJustDecodeBounds=false;options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>1600)options.inSampleSize*=2;Bitmap image;try(InputStream in=getContentResolver().openInputStream(uri)){image=BitmapFactory.decodeStream(in,null,options);}if(image==null)throw new Exception();int orientation=1;try(InputStream in=getContentResolver().openInputStream(uri)){orientation=new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION,1);}catch(Exception ignored){}Matrix matrix=new Matrix();switch(orientation){case 2:matrix.setScale(-1,1);break;case 3:matrix.setRotate(180);break;case 4:matrix.setScale(1,-1);break;case 5:matrix.setRotate(90);matrix.postScale(-1,1);break;case 6:matrix.setRotate(90);break;case 7:matrix.setRotate(270);matrix.postScale(-1,1);break;case 8:matrix.setRotate(270);break;}Bitmap rotated=Bitmap.createBitmap(image,0,0,image.getWidth(),image.getHeight(),matrix,true);addPhoto(rotated,m.optString("name","Photo"));if(rotated!=image)rotated.recycle();image.recycle();}
            else if(request==AUDIO){JSONObject m=metadata(uri);if(m.optLong("size")>100000000)throw new IllegalArgumentException("Choose an audio file smaller than 100 MB.");if(array("media").length()>=120)throw new IllegalArgumentException("Your media collection is full. Remove a copy first.");String id=UUID.randomUUID().toString();File dest=new File(mediaDir,id+".audio");try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(dest)){if(in==null)throw new Exception();byte[] b=new byte[8192];int n;long total=0;while((n=in.read(b))!=-1){total+=n;if(total>100000000)throw new IllegalArgumentException("Choose an audio file smaller than 100 MB.");out.write(b,0,n);}}catch(Exception e){dest.delete();throw e;}m.put("id",id);m.put("file",dest.getName());m.put("kind","audio");m.put("size",dest.length());m.put("url","https://"+HOST+"/media/"+dest.getName());if(m.isNull("mime"))m.put("mime","audio/mpeg");JSONArray a=array("media");a.put(m);if(!prefs.edit().putString("media",a.toString()).commit()){dest.delete();throw new Exception();}js("Pocket.receiveMedia()");}
            else if(request==FILE){try{getContentResolver().takePersistableUriPermission(uri,data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}JSONObject m=metadata(uri);m.put("id",UUID.randomUUID().toString());m.put("uri",uri.toString());if(m.isNull("mime"))m.put("mime","*/*");JSONArray a=new JSONArray();a.put(m);JSONArray old=array("files");for(int n=0;n<old.length()&&a.length()<12;n++){JSONObject previous=old.getJSONObject(n);if(!uri.toString().equals(previous.optString("uri")))a.put(previous);}prefs.edit().putString("files",a.toString()).commit();js("Pocket.receiveMedia()");}
        }catch(IllegalArgumentException e){message(e.getMessage()==null?"This file could not be opened.":e.getMessage());}catch(Exception e){message("This file could not be opened or saved. Try another file.");}});
    }
    private void addPhoto(Bitmap image,String name)throws Exception{
        if(array("media").length()>=120)throw new IllegalArgumentException("Your media collection is full. Remove a copy first.");String id=UUID.randomUUID().toString();File dest=new File(mediaDir,id+".jpg");try(FileOutputStream out=new FileOutputStream(dest)){if(!image.compress(Bitmap.CompressFormat.JPEG,86,out))throw new Exception();}JSONObject m=new JSONObject();m.put("id",id);m.put("file",dest.getName());m.put("name",limited(name,200));m.put("kind","image");m.put("mime","image/jpeg");m.put("size",dest.length());m.put("url","https://"+HOST+"/media/"+dest.getName());JSONArray a=array("media");a.put(m);if(!prefs.edit().putString("media",a.toString()).commit()){dest.delete();throw new Exception();}js("Pocket.receiveMedia()");
    }
}
