(function (root) {
  'use strict';
  const text = (v, n = 1000) => typeof v === 'string' ? v.slice(0, n) : '';
  const id = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  const dateKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const validDate = v => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && dateKey(new Date(v+'T12:00:00')) === v;
  const validTime = v => typeof v === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
  const defaults = () => ({version:1,settings:{name:'Chris',theme:'dark',accent:'mint',wallpaper:'tide',textSize:100,motion:false,haptics:true},notes:[],tasks:[],events:[],contacts:[],bookmarks:[],favorites:['notes','tasks','calendar','clock','calculator','files','gallery','settings'],recents:[],calcHistory:[],timer:{end:0,remaining:0,running:false},stopwatch:{started:0,elapsed:0,running:false,laps:[]}});
  function cleanState(input, strict = false) {
    if (!input || typeof input !== 'object' || Array.isArray(input) || input.version !== 1) {
      if (strict) throw new Error('This is not a PocketDesk backup.');
      return defaults();
    }
    const out=defaults(), s=input.settings || {};
    out.settings={name:text(s.name,40)||'Chris',theme:['dark','light','system'].includes(s.theme)?s.theme:'dark',accent:['mint','peach','blue','rose'].includes(s.accent)?s.accent:'mint',wallpaper:['tide','dawn','ink','meadow'].includes(s.wallpaper)?s.wallpaper:'tide',textSize:[100,115,130].includes(s.textSize)?s.textSize:100,motion:s.motion===true,haptics:s.haptics!==false};
    const seen=new Set();
    const rows=(name,limit,fn)=>{if(input[name]!==undefined&&!Array.isArray(input[name])) {if(strict)throw new Error('The backup has a damaged '+name+' list.');return;}out[name]=(input[name]||[]).slice(0,limit).map(x=>{if(!x||typeof x!=='object'||Array.isArray(x))return null;const key=text(x.id,80);if(!/^[a-z0-9_-]{1,80}$/i.test(key)||seen.has(name+key))return null;seen.add(name+key);return fn(x,key);}).filter(Boolean);};
    rows('notes',500,(x,k)=>({id:k,title:text(x.title,150),body:text(x.body,50000),color:['mint','peach','blue','rose'].includes(x.color)?x.color:'peach',pinned:x.pinned===true,deleted:x.deleted===true,updated:Number.isFinite(x.updated)?x.updated:Date.now()}));
    rows('tasks',1000,(x,k)=>({id:k,title:text(x.title,200),due:validDate(x.due)?x.due:'',done:x.done===true,created:Number.isFinite(x.created)?x.created:Date.now()}));
    rows('events',1000,(x,k)=>validDate(x.date)?({id:k,title:text(x.title,200),date:x.date,time:validTime(x.time)?x.time:'',place:text(x.place,200),details:text(x.details,2000)}):null);
    rows('contacts',500,(x,k)=>({id:k,name:text(x.name,100),phone:text(x.phone,60),email:text(x.email,200),details:text(x.details,1000)}));
    rows('bookmarks',100,(x,k)=>{const url=safeUrl(x.url,false);return url?{id:k,title:text(x.title,100)||url,url}:null;});
    const appIds=['notes','tasks','calendar','clock','calculator','files','gallery','music','contacts','phone','messages','browser','camera','settings','help','device'];
    if(Array.isArray(input.favorites))out.favorites=[...new Set(input.favorites.filter(x=>appIds.includes(x)))].slice(0,8);
    if(Array.isArray(input.recents))out.recents=[...new Set(input.recents.filter(x=>appIds.includes(x)))].slice(0,8);
    if(Array.isArray(input.calcHistory))out.calcHistory=input.calcHistory.slice(0,30).filter(x=>x&&typeof x.expression==='string'&&typeof x.result==='string').map(x=>({expression:text(x.expression,100),result:text(x.result,100)}));
    const t=input.timer||{};out.timer={end:Number.isFinite(t.end)?Math.max(0,t.end):0,remaining:Number.isFinite(t.remaining)?Math.max(0,Math.min(t.remaining,86400000)):0,running:t.running===true&&Number.isFinite(t.end)&&t.end>0};
    const w=input.stopwatch||{};out.stopwatch={started:Number.isFinite(w.started)?Math.max(0,w.started):0,elapsed:Number.isFinite(w.elapsed)?Math.max(0,w.elapsed):0,running:w.running===true&&Number.isFinite(w.started)&&w.started>0,laps:Array.isArray(w.laps)?w.laps.filter(x=>Number.isFinite(x)&&x>=0).slice(0,100):[]};
    return out;
  }
  function safeUrl(value, search = true) {
    const v=text(value,2000).trim();if(!v)return '';
    if (/^[a-z][a-z\d+.-]*:/i.test(v)) {
      try{const u=new URL(v);return ['https:','http:'].includes(u.protocol)&&u.hostname&&!u.username&&!u.password?u.href:'';}catch(_){return '';}
    }
    if (/^[\w.-]+\.[a-z]{2,}(?::\d+)?(?:[/?#].*)?$/i.test(v)) {
      try{return new URL('https://'+v).href;}catch(_){return '';}
    }
    return search?'https://www.google.com/search?q='+encodeURIComponent(v):'';
  }
  function calculate(expression) {
    const src=text(expression,200).replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/\s/g,'');
    if(!src||!/^[\deE.()+\-*/%]+$/.test(src))throw new Error('Check the numbers.');
    let p=0;
    function number(){let v;if(src[p]==='('){p++;v=sum();if(src[p++]!==')')throw new Error('Close the bracket.');}else{const m=src.slice(p).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?/i);if(!m)throw new Error('Add a number.');p+=m[0].length;v=Number(m[0]);}while(src[p]==='%'){v/=100;p++;}return v;}
    function unary(){if(src[p]==='+'){p++;return unary();}if(src[p]==='-'){p++;return -unary();}return number();}
    function product(){let v=unary();while(src[p]==='*'||src[p]==='/'){const op=src[p++],b=unary();if(op==='/'&&b===0)throw new Error('You cannot divide by zero.');v=op==='*'?v*b:v/b;}return v;}
    function sum(){let v=product();while(src[p]==='+'||src[p]==='-'){const op=src[p++],b=product();v=op==='+'?v+b:v-b;}return v;}
    const result=sum();if(p!==src.length||!Number.isFinite(result))throw new Error('Check the calculation.');return Object.is(result,-0)?'0':String(Number(result.toPrecision(12)));
  }
  function monthCells(year,month){const first=new Date(year,month,1,12),offset=(first.getDay()+6)%7;return Array.from({length:42},(_,i)=>{const d=new Date(year,month,1-offset+i,12);return {date:dateKey(d),day:d.getDate(),inMonth:d.getMonth()===month};});}
  function duration(ms,precise=false){const n=Math.max(0,Math.floor(ms)),s=Math.floor(n/1000),h=Math.floor(s/3600),m=Math.floor(s/60)%60;return (h?String(h).padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0')+(precise?'.'+String(Math.floor(n%1000/10)).padStart(2,'0'):'');}
  const api={id,dateKey,validDate,validTime,defaults,cleanState,safeUrl,calculate,monthCells,duration,text};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;root.PocketCore=api;
})(typeof globalThis!=='undefined'?globalThis:this);
