const assert=require('node:assert/strict');
const C=require('../app/src/main/assets/core.js');
let checks=0;
const equal=(a,b)=>{assert.deepEqual(a,b);checks++;};
for(const [s,n] of [['2+3*4','14'],['(2+3)*4','20'],['200*10%','20'],['-3*-4','12'],['0.1+0.2','0.3'],['3+-2','1'],['100/4/5','5'],['.5+.25','0.75'],['(50+50)%','1'],['1e-7*10','0.000001'],['1e+15+2','1000000000000000'],['-(4+6)','-10'],['-0','0']])equal(C.calculate(s),n);
for(const s of ['1/0','1..2','2(3)','(','2+','alert(1)','Math.random()','1e++2','2;3','NaN','1e309']){assert.throws(()=>C.calculate(s));checks++;}
equal(C.safeUrl('example.com'), 'https://example.com/');equal(C.safeUrl('seoul aquarium'), 'https://www.google.com/search?q=seoul%20aquarium');equal(C.safeUrl('javascript:alert(1)'), '');equal(C.safeUrl('https://name:pass@example.com'), '');equal(C.safeUrl('file:///tmp/a'), '');equal(C.safeUrl('my note',false), '');
equal(C.validDate('2024-02-29'),true);equal(C.validDate('2026-02-29'),false);equal(C.validDate('2026-02-31'),false);equal(C.validTime('23:59'),true);equal(C.validTime('24:00'),false);equal(C.validTime('7:00'),false);
const cells=C.monthCells(2026,9);equal(cells.length,42);equal(cells[0].date,'2026-09-28');equal(cells.filter(x=>x.inMonth).length,31);equal(C.duration(3661000),'01:01:01');equal(C.duration(1537,true),'00:01.53');
const input={...C.defaults(),notes:[{id:'a',title:'<script>x</script>',body:'words',color:'wrong',pinned:true},{id:'a',title:'duplicate'},null],bookmarks:[{id:'bad',url:'javascript:alert(1)'},{id:'ok',title:'Example',url:'example.com'}],settings:{textSize:999,theme:'unknown',name:'Chris'},events:[{id:'e',date:'2026-02-31'}],favorites:['notes','notes','fake','settings']};
const clean=C.cleanState(input,true);equal(clean.notes.length,1);equal(clean.notes[0].title,'<script>x</script>');equal(clean.notes[0].color,'peach');equal(clean.bookmarks.length,1);equal(clean.settings.textSize,100);equal(clean.settings.theme,'dark');equal(clean.events.length,0);equal(clean.favorites,['notes','settings']);equal(C.cleanState(JSON.parse(JSON.stringify(clean)),true),clean);
assert.throws(()=>C.cleanState({version:2},true));checks++;assert.throws(()=>C.cleanState({version:1,notes:{}},true));checks++;
const proto=C.cleanState(JSON.parse('{"version":1,"__proto__":{"polluted":true},"settings":{"__proto__":{"polluted":true}}}'),true);equal({}.polluted,undefined);equal(proto.settings.theme,'dark');
equal(C.cleanState({...C.defaults(),notes:[{id:'" onclick="bad()',title:'Bad ID'}]},true).notes.length,0);
console.log(`${checks} core checks passed.`);
